# Resora Demo

A premium, cinematic luxury-marketplace homepage built to demonstrate the
future **Resora** platform — a curated, invitation-only marketplace
connecting discerning collectors with exceptional sellers of rare and
luxury goods.

Built with **Next.js 15 (App Router)**, **TypeScript**, **Tailwind CSS**,
**Framer Motion**, **Lucide React**, and a **Firebase-ready** configuration
layer.

---

## ✨ Features

- **Vault Intro** — a cinematic opening animation: a gold seam splits the
  screen and the Resora logo emerges from darkness, echoing a vault/showcase
  reveal.
- **Golden ambient lighting** — soft radial gold glows and shimmer sweeps
  used sparingly throughout the page.
- **Premium hero section** with luxury display typography and animated
  entrance sequence.
- **Featured Sellers showroom** — four seller cards (Syed, Mantasha, Zoya,
  Afshan) with profile imagery, specialty, rating, and curated item count.
- **Luxury product showcase** — an editorial two-column grid of showcased
  pieces with hover light-sweep interactions.
- **Manifesto** — a full-bleed cinematic pull-quote section.
- **Collections** — an asymmetric editorial grid (not a generic card grid).
- **Premium footer** with sitemap-style columns and social links.
- Fully **responsive**, accessible (visible focus states, reduced-motion
  support), and **SEO-ready** (metadata, Open Graph, robots.txt, sitemap.xml).

---

## 🧱 Tech Stack

| Layer      | Choice                         |
| ---------- | ------------------------------ |
| Framework  | Next.js 15 (App Router)        |
| Language   | TypeScript                     |
| Styling    | Tailwind CSS                   |
| Animation  | Framer Motion                  |
| Icons      | Lucide React                   |
| Backend    | Firebase (config placeholder)  |
| Fonts      | Cormorant Garamond + Inter     |

---

## 📁 Project Structure

```
resora-demo/
├── app/
│   ├── layout.tsx        # Root layout, fonts, metadata
│   ├── page.tsx          # Homepage composition
│   ├── robots.ts         # robots.txt route
│   ├── sitemap.ts        # sitemap.xml route
│   └── icon.svg          # Favicon
├── components/
│   ├── VaultIntro.tsx    # Opening vault-reveal animation
│   ├── Navbar.tsx        # Sticky luxury navigation
│   ├── Hero.tsx          # Cinematic hero section
│   ├── Sellers.tsx       # Featured sellers showroom
│   ├── Showcase.tsx      # Product showcase grid
│   ├── Manifesto.tsx     # Pull-quote manifesto section
│   ├── Collections.tsx   # Asymmetric collections grid
│   ├── CtaBanner.tsx     # Closing call-to-action
│   └── Footer.tsx        # Premium footer
├── lib/
│   ├── data.ts           # Sellers, products, collections demo data
│   └── firebase.ts       # Firebase config (placeholder, env-driven)
├── styles/
│   └── globals.css       # Tailwind layers + custom utilities
├── public/                # Static assets
├── .env.example           # Firebase env variable template
├── next.config.ts
├── tailwind.config.ts
├── postcss.config.js
├── tsconfig.json
└── package.json
```

---

## 🚀 Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment variables (optional)

Firebase is optional for this demo — the site runs fully without it.
To connect a real Firebase project later:

```bash
cp .env.example .env.local
```

Then fill in your Firebase project credentials in `.env.local`.

### 3. Run the development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

### 4. Build for production

```bash
npm run build
npm run start
```

---

## ▲ Deploying to Vercel

1. Push this repository to GitHub.
2. Import the repository into [Vercel](https://vercel.com/new).
3. Vercel will auto-detect Next.js — no build configuration needed.
4. (Optional) Add the Firebase environment variables from `.env.example`
   in your Vercel Project Settings → Environment Variables.
5. Deploy.

---

## 🎨 Design System

- **Palette:** Obsidian `#0A0908`, Charcoal `#141110`, Champagne Gold
  `#C6A567`, Ivory `#EFE9DD`, Bronze `#8A7355`.
- **Type:** Cormorant Garamond (display/serif) paired with Inter (body/UI).
- **Signature motif:** the "Vault Reveal" — a gold seam opening — reused
  subtly as a light-sweep hover state across product and seller imagery.

---

## 📄 License

This is a demo project created for showcase purposes.
